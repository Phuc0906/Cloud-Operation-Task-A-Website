document.getElementById("orderButton").addEventListener("click", function () {
    alert("Your order has been placed!");
});
